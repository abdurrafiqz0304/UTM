//Function Binding
#include <iostream>
using namespace std;

double getNumber() {
    return 9.5;
}

int main() {
    auto f = getNumber(); // Normal function call
    auto g = getNumber;   // This is function binding (not a function call)

    cout << f << endl;  
    cout << g << endl;  
    cout << g() << endl; 

    system("pause");
    return 0;
}
