//Returning Functions from a Function
#include <iostream>
using namespace std;

double add(double a, double b) { return a + b; }
double substract(double a, double b) { return a - b; }
double multiply(double a, double b) { return a * b; }
double divide(double a, double b) { return a / b; }

typedef double (BinaryFunction)(double, double);

BinaryFunction* getFunctionByOperator(char oper) {
    switch (oper) {
        case '+': return add;
        case '-': return substract;
        case '*': return multiply;
        case '/': return divide;
    }
    return NULL;
}

int main() {
    auto f = getFunctionByOperator('+');
    BinaryFunction* g = getFunctionByOperator('*');

    cout << f(2,3) << endl; 
    cout << f(12,5) << endl; 

    cout << g(2,3) << endl; 
    cout << g(12,5) << endl; 

    system("pause");
    return 0;
}
