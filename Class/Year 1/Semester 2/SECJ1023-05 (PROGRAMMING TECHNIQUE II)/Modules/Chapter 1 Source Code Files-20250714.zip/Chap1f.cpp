//High-order Functions and Callbacks
#include <iostream>
using namespace std;

typedef double (BinaryFunction)(double, double);

void doCalculation(double a, double b, BinaryFunction f) {
    double r = f(a, b);
    cout << "Result: " << r << endl;
}

double add(double a, double b) { return a + b; }
double multiply(double a, double b) { return a * b; }

int main() {
    doCalculation(1,2, add);     
    doCalculation(5,4, multiply); 
    
    system("pause");
    return 0;
}
