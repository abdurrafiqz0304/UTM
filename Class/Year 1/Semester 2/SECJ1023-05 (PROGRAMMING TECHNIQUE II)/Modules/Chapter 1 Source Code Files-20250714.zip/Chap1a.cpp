//Declarative Programming (used in FP)

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    vector<int> numbers = {1, 2, 3, 4, 5};
    
    // Declarative style using for_each
    for_each(numbers.begin(), numbers.end(), [](int n) {
        cout << n * n << " "; 
    });
    cout << endl;

    system("pause");
    return 0;
}
