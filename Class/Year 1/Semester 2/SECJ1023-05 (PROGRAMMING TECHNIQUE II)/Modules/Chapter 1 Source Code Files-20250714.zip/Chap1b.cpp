//Imperative Programming  (used in Procedural and OOP)
#include <iostream>
#include <vector>
using namespace std;

int main() {
    vector<int> numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int result = 0;

    for (int num : numbers) {
        if (num % 2 == 0) {
            result += num * 10;
        }
    }

    cout << "Result: " << result << endl;
    
    system("pause");
    return 0;
}
