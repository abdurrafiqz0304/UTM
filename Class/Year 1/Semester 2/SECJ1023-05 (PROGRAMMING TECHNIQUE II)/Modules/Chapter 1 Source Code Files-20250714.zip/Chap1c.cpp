//Functional Programming with high-order functions
#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>
using namespace std;

int main() {
    vector<int> numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    int result = accumulate(numbers.begin(), numbers.end(), 0, 
        [](int sum, int n) { return (n % 2 == 0) ? sum + (n * 10) : sum; });

    cout << "Result: " << result << endl;
    
    system("pause");
    return 0;
}
