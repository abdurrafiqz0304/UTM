#include "Flight.h"

Flight::Flight(string dest, int cap, double tPrice, double disc)
    : destination(dest), capacity(cap), ticketPrice(tPrice), discount(disc), no_passenger(0), status("normal"), totalPayment(0.0) {}

void Flight::book(int numPassengers, string stat) {
    if (no_passenger + numPassengers > capacity) {
        cout << "Booking failed. Exceeds capacity! << endl";
        return;
    } 

    double effectivePrice = ticketPrice;
    if (passengersStatus == "Senior Citizen") {
        effectivePrice *= (1 - (discount / 100)); // 50% discount for Senior Citizens
    }

    no_passenger += numPassengers;
    totalPayment += effectivePrice * numPassengers;
    status = stat;
}

void Flight::cancel(int numPassengers) {
    if (numPassengers > no_passenger) {
        cout << "Cancellation failed. Not enough passengers booked!" << endl;
        return;
    }

    no_Passenger -= numPassengers;
    double refund = (ticketPrice * 0.5) * numPassengers;
    totalPayment -= refund;
}

void Flight::checkDetail() {
    cout << "Flight Details:" << endl;
    cout << "Destination: " << destination << endl;
    cout << "Number of Passengers: " << no_passenger << endl;
    cout << "Capacity: " << capacity << endl;
    cout << "Status: " << status << endl;
    cout << "Total Payment Collected: RM" << totalPayment << endl;
}