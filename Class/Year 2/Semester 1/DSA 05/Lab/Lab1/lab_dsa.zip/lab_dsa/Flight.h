#ifndef FLIGHT_H
#define FLIGHT_H

#include <iostream>
#include <string>
using namespace std;

class Flight {
    string destination;
    int no_passenger;
    int capacity;
    string status;
    double ticketPrice;
    double discount;
    double totalPayment;

    public:
    Flight(string dest = "Unknown", int cap = 100, double tPrice = 100.00, double disc = 0.0);

    void book(int numPassengers, string stat = "normal");
    void cancel(int numPassengers);
    void checkDetail();
};

#endif // FLIGHT_H

