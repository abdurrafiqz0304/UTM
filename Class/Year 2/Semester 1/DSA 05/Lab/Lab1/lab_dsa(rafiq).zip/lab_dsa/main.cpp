#include "Flight.h"

int main() {

    // Part (c) using pointer
    Flight *Flight1;
    Flight1 = new Flight("Kuching", 150, 120.00, 50);

    Flight1->book(20, "senior citizen");
    Flight1->cancel(2);
    Flight1->checkDetail();

    delete Flight1;

    // Part (d) multiple flights using array
    Flight flights[3] = {
        Flight("Kuala Lumpur", 200, 150.0, 40),
        Flight("Kuching", 120, 180.0, 30),
        Flight("Langkawi", 80, 220.0, 25)
    };

    for (int i = 0; i < 3; i++) {
        cout << "\nBooking for Flight " << i+1 << endl;
        flights[i].book(10, "normal");
        flights[i].cancel(2);
    }

    cout << "\nDisplaying all flight details:\n";
    for (int i = 0; i < 3; i++) {
        flights[i].checkDetail();
    }

    system("pause");
    return 0;
}
