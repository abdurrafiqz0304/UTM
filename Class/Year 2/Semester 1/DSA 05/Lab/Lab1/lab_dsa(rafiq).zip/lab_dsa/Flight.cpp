#include "Flight.h"

// Constructor initializes all members, setting defaults for those not provided
Flight::Flight(string dest, int cap, double tPrice, double disc)
    : destination(dest), capacity(cap), ticketPrice(tPrice), discount(disc), no_passenger(0), status("normal"), totalPayment(0.0) {}

void Flight::book(int numPassengers, string stat) {
    // Check if booking exceeds capacity [cite: 32]
    if (no_passenger + numPassengers > capacity) {
        // Corrected: Added closing quote
        cout << "Booking failed. Exceeds capacity!" << endl;
        return;
    } 

    double effectivePrice = ticketPrice;
    
    // Corrected: Used 'stat' parameter and lowercase "senior citizen" [cite: 29, 30]
    if (stat == "senior citizen") {
        // Applies the discount (e.g., 50% for Flight1)
        effectivePrice *= (1 - (discount / 100.0)); 
    }

    // Update passenger count and total payment [cite: 31]
    no_passenger += numPassengers;
    totalPayment += effectivePrice * numPassengers;
    status = stat; // Update the flight's general status (might be better to track per passenger, but following lab)
}

void Flight::cancel(int numPassengers) {
    if (numPassengers > no_passenger) {
        cout << "Cancellation failed. Not enough passengers booked!" << endl;
        return;
    }

    // Corrected: 'no_passenger' typo fixed [cite: 37]
    no_passenger -= numPassengers;
    
    // Calculate 50% refund and update total payment [cite: 38, 39]
    double refund = (ticketPrice * 0.5) * numPassengers;
    totalPayment -= refund;
}

void Flight::checkDetail() {
    // Print all required information [cite: 40]
    cout << "\n--- Flight Details ---" << endl;
    cout << "Destination: " << destination << endl;
    cout << "Number of Passengers: " << no_passenger << endl;
    cout << "Capacity: " << capacity << endl;
    cout << "Ticket Price: RM" << ticketPrice << endl;
    cout << "Senior Discount: " << discount << "%" << endl;
    cout << "Total Payment Collected: RM" << totalPayment << endl;
    cout << "----------------------" << endl;
}